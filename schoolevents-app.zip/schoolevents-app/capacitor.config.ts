import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'es.safa.schoolevents',
  appName: 'SchoolEvents',
  webDir: 'www'
};

export default config;
