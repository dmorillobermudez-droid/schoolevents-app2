# SchoolEvents

App móvil para la comunidad escolar: consulta los próximos eventos del centro (ferias, torneos,
festivales…), apúntate con un toque, mira el calendario, revisa la galería de fotos y recibe avisos.

Proyecto de **2.º DAM · Desarrollo de aplicaciones móviles** hecho con **Angular 22 · Ionic 9 · Capacitor 8**
(componentes *standalone*). Esta primera entrega es solo la interfaz: los datos son de maqueta
(`src/app/datos/`) y todavía no hay servidor.

## Cómo ejecutarla

```bash
npm install          # instala dependencias (incluidas las fuentes Inter y Poppins)
ionic serve          # abre la app en el navegador (usa el modo móvil de F12)
```

Para Android:

```bash
ionic build
npx cap add android      # solo la primera vez
npx cap sync
npx cap run android
```

## Pantallas

| Pantalla | Ruta | Menú |
|---|---|---|
| Login / registro | `/login` | no |
| Inicio | `/app/inicio` | sí |
| Ficha de evento (desde Inicio) | `/app/inicio/:id` | sí |
| Calendario | `/app/calendario` | sí |
| Nuevo evento (formulario) | `/app/calendario/nuevo` | sí |
| Ficha de evento (desde Calendario o Perfil) | `/app/calendario/:id` | sí |
| Galería | `/app/galeria` | sí |
| Perfil | `/app/perfil` | sí |
| Notificaciones (pantalla completa) | `/notificaciones` | no |
| Página 404 | `**` | no |

### Capturas

Modo claro y modo oscuro de cada pantalla (carpeta [`capturas/`](capturas)):

| Pantalla | Claro | Oscuro |
|---|---|---|
| Login | ![Login claro](capturas/login-claro.png) | ![Login oscuro](capturas/login-oscuro.png) |
| Inicio | ![Inicio claro](capturas/inicio-claro.png) | ![Inicio oscuro](capturas/inicio-oscuro.png) |
| Calendario | ![Calendario claro](capturas/calendario-claro.png) | ![Calendario oscuro](capturas/calendario-oscuro.png) |
| Ficha de evento | ![Evento claro](capturas/evento-claro.png) | ![Evento oscuro](capturas/evento-oscuro.png) |
| Nuevo evento | ![Nuevo claro](capturas/nuevo-claro.png) | ![Nuevo oscuro](capturas/nuevo-oscuro.png) |
| Galería | ![Galería clara](capturas/galeria-claro.png) | ![Galería oscura](capturas/galeria-oscuro.png) |
| Perfil | ![Perfil claro](capturas/perfil-claro.png) | ![Perfil oscuro](capturas/perfil-oscuro.png) |
| Notificaciones | ![Notif. claro](capturas/notificaciones-claro.png) | ![Notif. oscuro](capturas/notificaciones-oscuro.png) |
| 404 | ![404 claro](capturas/404-claro.png) | ![404 oscuro](capturas/404-oscuro.png) |

## Diseño

### Paleta

| Color | Variable | Hex | Uso |
|---|---|---|---|
| Morado | `primary` | `#c820e0` | Cabeceras, botones, pestaña activa, categoría Ciencia |
| Naranja | `secondary` | `#ff6b2b` | Categoría Cultural |
| Amarillo | `tertiary` | `#ffd000` | Detalles y destacados |
| Verde | `success` | `#4ea80f` | Inscrito, categoría Deporte |
| Rosa pastel | fondo | `#fdeaea` | Fondo de las pantallas |
| Ciruela | texto | `#2b262c` | Títulos y textos |

El modo oscuro (interruptor en **Perfil**) usa un fondo `#160a19`, tarjetas `#241328` y un morado
más claro (`#e27af0`) para que se lea bien. Todas las variables están en `src/theme/variables.scss`.

### Tipografías

- **Poppins** (600 / 700 / 800): títulos.
- **Inter** (400–700): textos.

Se instalan con npm (`@fontsource/*`), así que funcionan sin conexión.

### Componentes de Ionic personalizados

Menú inferior (línea morada e icono relleno en la pestaña activa), botones, tarjetas, buscador,
segmento en forma de píldora, listas agrupadas, campos con contorno y modal tipo hoja
(ver `src/global.scss` y `tabs.page.scss`).

## Árbol de rutas

```
/                       → redirige a /login
/login                  Login / registro                      (sin menú)
/app                    TabsPage (menú inferior)
 ├─ inicio              Inicio
 │   └─ inicio/:id      Ficha de evento
 ├─ calendario          Calendario
 │   ├─ calendario/nuevo  Formulario de nuevo evento
 │   └─ calendario/:id    Ficha de evento
 ├─ galeria             Galería
 └─ perfil              Perfil
/notificaciones         Notificaciones                        (pantalla completa, sin menú)
**                      Página 404                            (sin menú)
```

## Árbol de componentes

```
AppComponent
├─ LoginPage
├─ TabsPage
│   ├─ InicioPage
│   │   ├─ app-tarjeta-resumen        (×3)
│   │   ├─ app-tarjeta-destacada
│   │   │   └─ app-icono-categoria
│   │   ├─ app-fila-evento            (×n)
│   │   │   ├─ app-icono-categoria
│   │   │   └─ app-chip-categoria
│   │   └─ app-estado-vacio           (con <ng-content>)
│   ├─ CalendarioPage
│   │   ├─ app-fila-evento
│   │   └─ app-estado-vacio
│   ├─ EventoDetallePage
│   │   ├─ app-chip-categoria
│   │   └─ app-estado-vacio
│   ├─ EventoNuevoPage
│   ├─ GaleriaPage
│   │   ├─ app-tarjeta-foto
│   │   │   └─ app-chip-categoria
│   │   └─ app-estado-vacio
│   └─ PerfilPage
│       ├─ app-fila-evento
│       └─ app-estado-vacio
├─ NotificacionesPage
│   ├─ app-tarjeta-notificacion
│   └─ app-estado-vacio
└─ NoEncontradaPage
```

## Estructura del código

```
src/app/
├─ componentes/   8 componentes propios reutilizables (con input(); estado-vacio usa ng-content)
├─ datos/         datos de maqueta (eventos, fotos, notificaciones)
├─ modelos/       interfaces (Evento, Foto, Notificacion)
├─ paginas/       una carpeta por pantalla
├─ pipes/         fecha.pipe.ts
└─ app.routes.ts  mapa de rutas
```

## Qué se ve en cada requisito

- **Login fuera del menú** con `routerDirection="root"` al entrar y al cerrar sesión.
- **Menú inferior** de 4 pestañas con `ion-tabs`, visible también en las fichas y en el formulario.
- **Detalle con `:id`**: la ficha lee el id con `input()` y busca el evento.
- **Pantalla completa** (Notificaciones) y **404**.
- **`@for`, `@if`, `@switch` y `@empty`** en listas, estados vacíos y chips de categoría.
- **Lista, tarjeta, chip, segmento, buscador, formulario (texto, área de texto, segmento, fecha,
  selector, interruptor), modal y botón flotante.**
- **Estados vacíos** en Inicio, Calendario, Galería, Notificaciones y Perfil.

## Créditos

Origen de las fotos y recursos en [`CREDITOS.md`](CREDITOS.md).
