import { Pipe, PipeTransform } from '@angular/core';

const MESES = ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'];
const MESES_LARGOS = [
  'enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio',
  'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre',
];

/** Convierte '2026-09-20' en «20 Sep» (corta), «20 Sep 2026» (media) o «20 de septiembre» (larga). */
@Pipe({ name: 'fecha' })
export class FechaPipe implements PipeTransform {
  transform(iso: string, formato: 'corta' | 'media' | 'larga' = 'corta'): string {
    const [anio, mes, dia] = iso.split('-').map(Number);
    switch (formato) {
      case 'larga':
        return `${dia} de ${MESES_LARGOS[mes - 1]}`;
      case 'media':
        return `${dia} ${MESES[mes - 1]} ${anio}`;
      default:
        return `${dia} ${MESES[mes - 1]}`;
    }
  }
}
