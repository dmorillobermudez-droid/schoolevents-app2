import { Routes } from '@angular/router';

export const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },

  // ── Fuera del menú ───────────────────────────────────────────
  {
    path: 'login',
    loadComponent: () => import('./paginas/login/login.page').then((m) => m.LoginPage),
  },

  // ── Dentro del menú inferior ─────────────────────────────────
  {
    path: 'app',
    loadComponent: () => import('./paginas/tabs/tabs.page').then((m) => m.TabsPage),
    children: [
      {
        path: 'inicio',
        loadComponent: () => import('./paginas/inicio/inicio.page').then((m) => m.InicioPage),
      },
      {
        path: 'inicio/:id',   // ficha de evento abierta desde Inicio
        loadComponent: () =>
          import('./paginas/evento-detalle/evento-detalle.page').then((m) => m.EventoDetallePage),
      },
      {
        path: 'calendario',
        loadComponent: () =>
          import('./paginas/calendario/calendario.page').then((m) => m.CalendarioPage),
      },
      {
        path: 'calendario/nuevo',   // las rutas fijas van ANTES que las que tienen :id
        loadComponent: () =>
          import('./paginas/evento-nuevo/evento-nuevo.page').then((m) => m.EventoNuevoPage),
      },
      {
        path: 'calendario/:id',   // ficha de evento abierta desde Calendario o Perfil
        loadComponent: () =>
          import('./paginas/evento-detalle/evento-detalle.page').then((m) => m.EventoDetallePage),
      },
      {
        path: 'galeria',
        loadComponent: () => import('./paginas/galeria/galeria.page').then((m) => m.GaleriaPage),
      },
      {
        path: 'perfil',
        loadComponent: () => import('./paginas/perfil/perfil.page').then((m) => m.PerfilPage),
      },
      { path: '', redirectTo: 'inicio', pathMatch: 'full' },
    ],
  },

  // ── Pantalla completa, sin menú ──────────────────────────────
  {
    path: 'notificaciones',
    loadComponent: () =>
      import('./paginas/notificaciones/notificaciones.page').then((m) => m.NotificacionesPage),
  },

  // ── Cualquier otra dirección: SIEMPRE LA ÚLTIMA ──────────────
  {
    path: '**',
    loadComponent: () =>
      import('./paginas/no-encontrada/no-encontrada.page').then((m) => m.NoEncontradaPage),
  },
];
