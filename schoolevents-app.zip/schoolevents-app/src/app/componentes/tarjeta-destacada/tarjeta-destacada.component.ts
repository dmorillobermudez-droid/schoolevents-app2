import { Component, input } from '@angular/core';
import { RouterLink } from '@angular/router';
import { IonButton, IonCard, IonChip, IonIcon, IonRouterLink } from '@ionic/angular';
import { Evento } from '../../modelos/evento';
import { FechaPipe } from '../../pipes/fecha.pipe';
import { IconoCategoriaComponent } from '../icono-categoria/icono-categoria.component';

@Component({
  selector: 'app-tarjeta-destacada',
  templateUrl: './tarjeta-destacada.component.html',
  styleUrls: ['./tarjeta-destacada.component.scss'],
  imports: [RouterLink, IonRouterLink, IonCard, IonChip, IonButton, IonIcon, FechaPipe, IconoCategoriaComponent],
})
export class TarjetaDestacadaComponent {
  evento = input.required<Evento>();
  base = input('/app/inicio');
}
