import { Component, input } from '@angular/core';
import { IonCard, IonIcon } from '@ionic/angular';
import { Notificacion } from '../../modelos/notificacion';

@Component({
  selector: 'app-tarjeta-notificacion',
  templateUrl: './tarjeta-notificacion.component.html',
  styleUrls: ['./tarjeta-notificacion.component.scss'],
  imports: [IonCard, IonIcon],
})
export class TarjetaNotificacionComponent {
  notificacion = input.required<Notificacion>();
}
