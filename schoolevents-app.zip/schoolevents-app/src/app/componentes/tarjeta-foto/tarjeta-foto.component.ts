import { Component, input, signal } from '@angular/core';
import { IonIcon } from '@ionic/angular';
import { Foto } from '../../modelos/foto';
import { ChipCategoriaComponent } from '../chip-categoria/chip-categoria.component';

@Component({
  selector: 'app-tarjeta-foto',
  templateUrl: './tarjeta-foto.component.html',
  styleUrls: ['./tarjeta-foto.component.scss'],
  imports: [IonIcon, ChipCategoriaComponent],
})
export class TarjetaFotoComponent {
  foto = input.required<Foto>();
  meGusta = signal(false);          // estado propio de cada tarjeta

  alternarMeGusta() {
    this.meGusta.update((v) => !v);
  }
}
