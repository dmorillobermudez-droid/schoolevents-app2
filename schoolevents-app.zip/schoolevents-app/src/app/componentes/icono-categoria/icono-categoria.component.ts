import { Component, computed, input } from '@angular/core';
import { IonIcon } from '@ionic/angular';
import { Categoria } from '../../modelos/evento';

const ICONOS: Record<Categoria, string> = {
  CIENCIA: 'flask-outline',
  DEPORTE: 'football-outline',
  CULTURAL: 'color-palette-outline',
};

@Component({
  selector: 'app-icono-categoria',
  templateUrl: './icono-categoria.component.html',
  styleUrls: ['./icono-categoria.component.scss'],
  imports: [IonIcon],
})
export class IconoCategoriaComponent {
  categoria = input.required<Categoria>();
  tamano = input(44);   // lado del cuadrado, en píxeles
  icono = computed(() => ICONOS[this.categoria()]);
}
