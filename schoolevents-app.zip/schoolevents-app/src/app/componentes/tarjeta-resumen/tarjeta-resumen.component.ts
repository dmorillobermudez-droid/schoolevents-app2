import { Component, input } from '@angular/core';
import { IonIcon } from '@ionic/angular';

@Component({
  selector: 'app-tarjeta-resumen',
  templateUrl: './tarjeta-resumen.component.html',
  styleUrls: ['./tarjeta-resumen.component.scss'],
  imports: [IonIcon],
})
export class TarjetaResumenComponent {
  icono = input.required<string>();
  numero = input.required<number>();
  texto = input.required<string>();
  color = input<'primary' | 'success' | 'warning'>('primary');
}
