import { Component, input } from '@angular/core';
import { RouterLink } from '@angular/router';
import { IonIcon, IonRouterLink } from '@ionic/angular';
import { Evento } from '../../modelos/evento';
import { FechaPipe } from '../../pipes/fecha.pipe';
import { IconoCategoriaComponent } from '../icono-categoria/icono-categoria.component';
import { ChipCategoriaComponent } from '../chip-categoria/chip-categoria.component';

@Component({
  selector: 'app-fila-evento',
  templateUrl: './fila-evento.component.html',
  styleUrls: ['./fila-evento.component.scss'],
  imports: [RouterLink, IonRouterLink, IonIcon, FechaPipe, IconoCategoriaComponent, ChipCategoriaComponent],
})
export class FilaEventoComponent {
  evento = input.required<Evento>();
  base = input('/app/inicio');   // pestaña desde la que se abre la ficha
}
