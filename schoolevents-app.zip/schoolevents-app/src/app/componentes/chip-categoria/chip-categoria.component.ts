import { Component, input } from '@angular/core';
import { Categoria } from '../../modelos/evento';

@Component({
  selector: 'app-chip-categoria',
  templateUrl: './chip-categoria.component.html',
  styleUrls: ['./chip-categoria.component.scss'],
})
export class ChipCategoriaComponent {
  categoria = input.required<Categoria>();
}
