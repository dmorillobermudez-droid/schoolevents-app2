export type Categoria = 'CIENCIA' | 'DEPORTE' | 'CULTURAL';

/** Un evento del colegio. Los campos con «?» son opcionales. */
export interface Evento {
  id: number;
  titulo: string;
  categoria: Categoria;
  fecha: string;        // formato AAAA-MM-DD
  horaInicio: string;   // HH:mm
  horaFin: string;      // HH:mm
  lugar: string;
  descripcion: string;
  requisitos: string[];
  interesados: number;
  asistentes: number;
  destacado: boolean;
  inscrito: boolean;
  organizador?: string;
  plazas?: number;
}
