export interface Notificacion {
  id: number;
  icono: string;      // nombre de un icono de Ionicons
  titulo: string;
  texto: string;
  hace: string;
  leida: boolean;
}
