import { Categoria } from './evento';

export interface Foto {
  id: number;
  titulo: string;
  descripcion: string;
  categoria: Categoria;
  url: string;
  likes: number;
}
