import { Foto } from '../modelos/foto';

const U = 'https://images.unsplash.com/';
const P = '?auto=format&fit=crop&w=500&q=80';

export const FOTOS: Foto[] = [
  { id: 1, titulo: 'Torneo deportivo', descripcion: 'Competición escolar de esquí alpino', categoria: 'DEPORTE', url: `${U}photo-1551698618-1dfe5d97d256${P}`, likes: 47 },
  { id: 2, titulo: 'Festival cultural', descripcion: 'Música en vivo y convivencia juvenil', categoria: 'CULTURAL', url: `${U}photo-1523580494863-6f3031224c94${P}`, likes: 132 },
  { id: 3, titulo: 'Torneo deportivo', descripcion: 'Carreras de velocidad y relevos en pista', categoria: 'DEPORTE', url: `${U}photo-1461896836934-ffe607ba8211${P}`, likes: 76 },
  { id: 4, titulo: 'Taller de arte', descripcion: 'Exposición de pintura y diseño creativo', categoria: 'CULTURAL', url: `${U}photo-1513364776144-60967b0f800f${P}`, likes: 76 },
  { id: 5, titulo: 'Feria de ciencias', descripcion: 'Proyectos de química, física y robótica', categoria: 'CIENCIA', url: `${U}photo-1532094349884-543bc11b234d${P}`, likes: 47 },
  { id: 6, titulo: 'Excursión de fin de curso', descripcion: 'Salida grupal y actividades al aire libre', categoria: 'CULTURAL', url: `${U}photo-1529156069898-49953e39b3ac${P}`, likes: 200 },
];
