import { Notificacion } from '../modelos/notificacion';

export const NOTIFICACIONES: Notificacion[] = [
  {
    id: 1,
    icono: 'alarm-outline',
    titulo: 'Recordatorio: Feria de ciencias',
    texto: 'El evento empieza mañana a las 9:00. ¡No olvides llevar tu proyecto!',
    hace: 'Hace 2 h',
    leida: false,
  },
  {
    id: 2,
    icono: 'checkmark-circle-outline',
    titulo: 'Inscripción confirmada',
    texto: 'Te registraste en el Festival Cultural de Primavera. ¡Nos vemos el 25 de septiembre!',
    hace: 'Hace 5 h',
    leida: false,
  },
  {
    id: 3,
    icono: 'refresh-outline',
    titulo: 'Cambio de horario',
    texto: 'El Torneo de fútbol cambia al lunes 28 a las 8:00. Actualiza tu agenda.',
    hace: 'Ayer',
    leida: true,
  },
  {
    id: 4,
    icono: 'trophy-outline',
    titulo: 'Resultados disponibles',
    texto: 'Ya puedes ver los resultados de las Olimpiadas de Matemáticas del curso pasado.',
    hace: 'Hace 3 días',
    leida: true,
  },
  {
    id: 5,
    icono: 'camera-outline',
    titulo: 'Fotos disponibles',
    texto: 'Las fotos del Taller de arte ya están en la galería. ¡Etiquétate!',
    hace: 'Hace 5 días',
    leida: true,
  },
];
