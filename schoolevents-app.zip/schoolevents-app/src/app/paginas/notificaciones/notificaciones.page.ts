import { Component } from '@angular/core';
import {
  IonBackButton, IonButton, IonButtons, IonContent, IonHeader, IonIcon, IonTitle, IonToolbar,
} from '@ionic/angular';
import { NOTIFICACIONES } from '../../datos/notificaciones';
import { Notificacion } from '../../modelos/notificacion';
import { EstadoVacioComponent } from '../../componentes/estado-vacio/estado-vacio.component';
import { TarjetaNotificacionComponent } from '../../componentes/tarjeta-notificacion/tarjeta-notificacion.component';

@Component({
  selector: 'app-notificaciones',
  templateUrl: './notificaciones.page.html',
  styleUrls: ['./notificaciones.page.scss'],
  imports: [
    IonHeader, IonToolbar, IonTitle, IonButtons, IonBackButton, IonButton, IonIcon, IonContent,
    EstadoVacioComponent, TarjetaNotificacionComponent,
  ],
})
export class NotificacionesPage {
  get sinLeer(): Notificacion[] {
    return NOTIFICACIONES.filter((n) => !n.leida);
  }
  get leidas(): Notificacion[] {
    return NOTIFICACIONES.filter((n) => n.leida);
  }

  marcarTodasLeidas() {
    NOTIFICACIONES.forEach((n) => (n.leida = true));
  }
}
