import { Component, inject, input } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import {
  IonBackButton, IonButton, IonButtons, IonCheckbox, IonContent, IonFooter, IonHeader, IonIcon,
  IonInput, IonModal, IonSelect, IonSelectOption, IonTitle, IonToolbar,
} from '@ionic/angular';
import { EVENTOS } from '../../datos/eventos';
import { Evento } from '../../modelos/evento';
import { ChipCategoriaComponent } from '../../componentes/chip-categoria/chip-categoria.component';
import { EstadoVacioComponent } from '../../componentes/estado-vacio/estado-vacio.component';
import { FechaPipe } from '../../pipes/fecha.pipe';

@Component({
  selector: 'app-evento-detalle',
  templateUrl: './evento-detalle.page.html',
  styleUrls: ['./evento-detalle.page.scss'],
  imports: [
    FormsModule, IonHeader, IonToolbar, IonTitle, IonButtons, IonBackButton, IonContent, IonFooter,
    IonButton, IonIcon, IonModal, IonInput, IonSelect, IonSelectOption, IonCheckbox,
    ChipCategoriaComponent, EstadoVacioComponent, FechaPipe,
  ],
})
export class EventoDetallePage {
  private router = inject(Router);

  id = input<string>();                 // recibe el ":id" de la dirección
  interesado = false;
  modalAbierto = false;
  acepta = false;
  cursos = ['1.º ESO', '2.º ESO', '3.º ESO', '4.º ESO', '1.º Bachillerato', '2.º Bachillerato'];

  get evento(): Evento | undefined {
    return EVENTOS.find((e) => e.id === Number(this.id()));
  }

  // El botón atrás vuelve a la pestaña desde la que se abrió la ficha
  get volverA(): string {
    return this.router.url.startsWith('/app/calendario') ? '/app/calendario' : '/app/inicio';
  }

  alternarInteres(e: Evento) {
    this.interesado = !this.interesado;
    e.interesados += this.interesado ? 1 : -1;
  }

  pulsarAsistire(e: Evento) {
    if (e.inscrito) {
      e.inscrito = false;               // cancelar inscripción
      e.asistentes -= 1;
    } else {
      this.acepta = false;
      this.modalAbierto = true;         // abre la hoja de inscripción
    }
  }

  confirmarInscripcion(e: Evento) {
    e.inscrito = true;
    e.asistentes += 1;
    this.modalAbierto = false;
  }
}
