import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { IonContent, IonIcon, IonLabel, IonSegment, IonSegmentButton } from '@ionic/angular';
import { FOTOS } from '../../datos/fotos';
import { Categoria } from '../../modelos/evento';
import { Foto } from '../../modelos/foto';
import { EstadoVacioComponent } from '../../componentes/estado-vacio/estado-vacio.component';
import { TarjetaFotoComponent } from '../../componentes/tarjeta-foto/tarjeta-foto.component';

@Component({
  selector: 'app-galeria',
  templateUrl: './galeria.page.html',
  styleUrls: ['./galeria.page.scss'],
  imports: [
    FormsModule, IonContent, IonIcon, IonLabel, IonSegment, IonSegmentButton,
    EstadoVacioComponent, TarjetaFotoComponent,
  ],
})
export class GaleriaPage {
  filtro: 'TODAS' | Categoria = 'TODAS';
  filtros: { valor: 'TODAS' | Categoria; texto: string }[] = [
    { valor: 'TODAS', texto: 'Todos' },
    { valor: 'CIENCIA', texto: 'Ciencia' },
    { valor: 'DEPORTE', texto: 'Deporte' },
    { valor: 'CULTURAL', texto: 'Cultural' },
  ];

  get fotos(): Foto[] {
    return FOTOS.filter((f) => this.filtro === 'TODAS' || f.categoria === this.filtro);
  }
}
