import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import {
  IonButton, IonContent, IonFab, IonFabButton, IonIcon, IonLabel, IonRouterLink,
  IonSearchbar, IonSegment, IonSegmentButton,
} from '@ionic/angular';
import { EVENTOS } from '../../datos/eventos';
import { Categoria, Evento } from '../../modelos/evento';
import { EstadoVacioComponent } from '../../componentes/estado-vacio/estado-vacio.component';
import { FilaEventoComponent } from '../../componentes/fila-evento/fila-evento.component';
import { FechaPipe } from '../../pipes/fecha.pipe';

const MESES = [
  'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
  'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre',
];

@Component({
  selector: 'app-calendario',
  templateUrl: './calendario.page.html',
  styleUrls: ['./calendario.page.scss'],
  imports: [
    FormsModule, RouterLink, IonRouterLink, IonContent, IonButton, IonIcon, IonLabel, IonFab,
    IonFabButton, IonSearchbar, IonSegment, IonSegmentButton, FechaPipe, EstadoVacioComponent,
    FilaEventoComponent,
  ],
})
export class CalendarioPage {
  anio = 2026;
  mes = 8;                                  // 0 = enero → 8 = septiembre
  busqueda = '';
  filtro: 'TODAS' | Categoria = 'TODAS';
  diaSeleccionado: string | null = null;

  filtros: { valor: 'TODAS' | Categoria; texto: string }[] = [
    { valor: 'TODAS', texto: 'Todos' },
    { valor: 'CIENCIA', texto: 'Ciencia' },
    { valor: 'DEPORTE', texto: 'Deporte' },
    { valor: 'CULTURAL', texto: 'Cultural' },
  ];
  diasSemana = ['L', 'M', 'X', 'J', 'V', 'S', 'D'];

  get nombreMes(): string {
    return MESES[this.mes];
  }

  // Huecos antes del día 1 (null) + los días del mes
  get celdas(): (number | null)[] {
    const primero = new Date(this.anio, this.mes, 1).getDay();       // 0 = domingo
    const huecos = (primero + 6) % 7;                                 // la semana empieza en lunes
    const total = new Date(this.anio, this.mes + 1, 0).getDate();
    return [
      ...new Array<null>(huecos).fill(null),
      ...Array.from({ length: total }, (_, i) => i + 1),
    ];
  }

  get eventosDelMes(): Evento[] {
    return EVENTOS.filter((e) => e.fecha.startsWith(this.prefijoMes()));
  }

  // Lista según mes, día elegido, categoría y texto del buscador
  get eventosVisibles(): Evento[] {
    const texto = this.busqueda.toLowerCase();
    return this.eventosDelMes
      .filter((e) => !this.diaSeleccionado || e.fecha === this.diaSeleccionado)
      .filter((e) => this.filtro === 'TODAS' || e.categoria === this.filtro)
      .filter((e) => e.titulo.toLowerCase().includes(texto))
      .sort((a, b) => a.fecha.localeCompare(b.fecha));
  }

  private pad(n: number): string {
    return String(n).padStart(2, '0');
  }
  private prefijoMes(): string {
    return `${this.anio}-${this.pad(this.mes + 1)}`;
  }
  iso(dia: number): string {
    return `${this.prefijoMes()}-${this.pad(dia)}`;
  }
  tieneEventos(dia: number): boolean {
    return EVENTOS.some((e) => e.fecha === this.iso(dia));
  }

  elegirDia(dia: number) {
    const iso = this.iso(dia);
    this.diaSeleccionado = this.diaSeleccionado === iso ? null : iso;
  }

  cambiarMes(delta: number) {
    const nuevo = new Date(this.anio, this.mes + delta, 1);
    this.anio = nuevo.getFullYear();
    this.mes = nuevo.getMonth();
    this.diaSeleccionado = null;
  }

  limpiar() {
    this.busqueda = '';
    this.filtro = 'TODAS';
    this.diaSeleccionado = null;
  }
}
