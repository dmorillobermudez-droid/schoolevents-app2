import { Component } from '@angular/core';
import { IonIcon, IonLabel, IonTabBar, IonTabButton, IonTabs } from '@ionic/angular';

@Component({
  selector: 'app-tabs',
  templateUrl: './tabs.page.html',
  styleUrls: ['./tabs.page.scss'],
  imports: [IonTabs, IonTabBar, IonTabButton, IonIcon, IonLabel],
})
export class TabsPage {
  pestanaActiva = 'inicio';

  // ion-tabs avisa cada vez que cambia la pestaña
  cambiarPestana(evento: { tab: string }) {
    this.pestanaActiva = evento.tab;
  }
}
