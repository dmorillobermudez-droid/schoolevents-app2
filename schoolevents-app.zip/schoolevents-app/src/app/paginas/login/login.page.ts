import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import {
  IonButton, IonContent, IonIcon, IonInput, IonInputPasswordToggle, IonLabel,
  IonRouterLink, IonSegment, IonSegmentButton, IonSelect, IonSelectOption,
} from '@ionic/angular';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
  imports: [
    FormsModule, RouterLink, IonRouterLink, IonContent, IonButton, IonIcon, IonInput,
    IonInputPasswordToggle, IonSegment, IonSegmentButton, IonLabel, IonSelect, IonSelectOption,
  ],
})
export class LoginPage {
  modo: 'login' | 'registro' = 'login';
  cursos = ['1.º ESO', '2.º ESO', '3.º ESO', '4.º ESO', '1.º Bachillerato', '2.º Bachillerato'];
}
