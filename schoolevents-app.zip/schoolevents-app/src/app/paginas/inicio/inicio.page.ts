import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { IonBadge, IonButton, IonChip, IonContent, IonIcon, IonRouterLink } from '@ionic/angular';
import { EVENTOS, HOY } from '../../datos/eventos';
import { NOTIFICACIONES } from '../../datos/notificaciones';
import { Evento } from '../../modelos/evento';
import { EstadoVacioComponent } from '../../componentes/estado-vacio/estado-vacio.component';
import { FilaEventoComponent } from '../../componentes/fila-evento/fila-evento.component';
import { TarjetaDestacadaComponent } from '../../componentes/tarjeta-destacada/tarjeta-destacada.component';
import { TarjetaResumenComponent } from '../../componentes/tarjeta-resumen/tarjeta-resumen.component';
import { FechaPipe } from '../../pipes/fecha.pipe';

@Component({
  selector: 'app-inicio',
  templateUrl: './inicio.page.html',
  styleUrls: ['./inicio.page.scss'],
  imports: [
    RouterLink, IonRouterLink, IonContent, IonButton, IonIcon, IonBadge, IonChip, FechaPipe,
    EstadoVacioComponent, FilaEventoComponent, TarjetaDestacadaComponent, TarjetaResumenComponent,
  ],
})
export class InicioPage {
  // La semana que se ve en la cabecera (14 → 20 de septiembre)
  semana = [
    { iso: '2026-09-14', nombre: 'Lun', num: 14 },
    { iso: '2026-09-15', nombre: 'Mar', num: 15 },
    { iso: '2026-09-16', nombre: 'Mié', num: 16 },
    { iso: '2026-09-17', nombre: 'Jue', num: 17 },
    { iso: '2026-09-18', nombre: 'Vie', num: 18 },
    { iso: '2026-09-19', nombre: 'Sáb', num: 19 },
    { iso: '2026-09-20', nombre: 'Dom', num: 20 },
  ];
  diaSeleccionado: string | null = null;

  get sinLeer(): number {
    return NOTIFICACIONES.filter((n) => !n.leida).length;
  }
  get proximos(): number {
    return EVENTOS.filter((e) => e.fecha >= HOY).length;
  }
  get inscritos(): number {
    return EVENTOS.filter((e) => e.inscrito).length;
  }
  get estaSemana(): number {
    return EVENTOS.filter((e) => e.fecha >= this.semana[0].iso && e.fecha <= this.semana[6].iso).length;
  }
  get destacado(): Evento | undefined {
    return EVENTOS.find((e) => e.destacado);
  }

  // Si hay un día elegido se ven sus eventos; si no, los más cercanos
  get listado(): Evento[] {
    const ordenados = [...EVENTOS].sort((a, b) => a.fecha.localeCompare(b.fecha));
    if (this.diaSeleccionado) {
      return ordenados.filter((e) => e.fecha === this.diaSeleccionado);
    }
    return ordenados.filter((e) => !e.destacado && e.fecha >= HOY).slice(0, 4);
  }

  tieneEventos(iso: string): boolean {
    return EVENTOS.some((e) => e.fecha === iso);
  }

  elegirDia(iso: string) {
    this.diaSeleccionado = this.diaSeleccionado === iso ? null : iso;
  }
}
