import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import {
  IonBackButton, IonButton, IonButtons, IonContent, IonDatetime, IonDatetimeButton, IonHeader,
  IonIcon, IonInput, IonItem, IonLabel, IonList, IonModal, IonSegment, IonSegmentButton,
  IonSelect, IonSelectOption, IonTextarea, IonTitle, IonToggle, IonToolbar, NavController,
} from '@ionic/angular';
import { EVENTOS } from '../../datos/eventos';
import { Categoria } from '../../modelos/evento';

@Component({
  selector: 'app-evento-nuevo',
  templateUrl: './evento-nuevo.page.html',
  styleUrls: ['./evento-nuevo.page.scss'],
  imports: [
    FormsModule, IonHeader, IonToolbar, IonTitle, IonButtons, IonBackButton, IonButton, IonContent,
    IonInput, IonTextarea, IonSegment, IonSegmentButton, IonLabel, IonList, IonItem, IonSelect,
    IonSelectOption, IonToggle, IonDatetime, IonDatetimeButton, IonModal, IonIcon,
  ],
})
export class EventoNuevoPage {
  private nav = inject(NavController);

  titulo = '';
  categoria: Categoria = 'CIENCIA';
  fecha = '2026-09-22';
  lugar = 'Patio central';
  requiereInscripcion = true;
  descripcion = '';

  lugares = [
    'Auditorio Principal', 'Patio central', 'Polideportivo municipal',
    'Salón de actos', 'Laboratorio 3', 'Aula de plástica',
  ];

  get valido(): boolean {
    return this.titulo.trim().length > 0;
  }

  guardar() {
    if (!this.valido) return;
    const id = Math.max(...EVENTOS.map((e) => e.id)) + 1;
    EVENTOS.push({
      id,
      titulo: this.titulo.trim(),
      categoria: this.categoria,
      fecha: String(this.fecha).slice(0, 10),   // ion-datetime puede devolver AAAA-MM-DDTHH:mm
      horaInicio: '9:00',
      horaFin: '11:00',
      lugar: this.lugar,
      descripcion: this.descripcion.trim() || 'Sin descripción todavía.',
      requisitos: this.requiereInscripcion ? ['Inscripción previa en la app'] : [],
      interesados: 0,
      asistentes: 0,
      destacado: false,
      inscrito: false,
    });
    this.nav.navigateBack('/app/calendario');
  }
}
