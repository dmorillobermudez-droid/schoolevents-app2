import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import {
  IonButton, IonContent, IonIcon, IonItem, IonLabel, IonList, IonNote, IonRouterLink, IonToggle,
  ToggleCustomEvent,
} from '@ionic/angular';
import { EVENTOS } from '../../datos/eventos';
import { Evento } from '../../modelos/evento';
import { EstadoVacioComponent } from '../../componentes/estado-vacio/estado-vacio.component';
import { FilaEventoComponent } from '../../componentes/fila-evento/fila-evento.component';

@Component({
  selector: 'app-perfil',
  templateUrl: './perfil.page.html',
  styleUrls: ['./perfil.page.scss'],
  imports: [
    FormsModule, RouterLink, IonRouterLink, IonContent, IonButton, IonIcon, IonList, IonItem, IonLabel,
    IonNote, IonToggle, EstadoVacioComponent, FilaEventoComponent,
  ],
})
export class PerfilPage {
  // El interruptor refleja si el modo oscuro ya estaba activado
  oscuro = document.documentElement.classList.contains('ion-palette-dark');
  avisos = true;

  get inscripciones(): Evento[] {
    return EVENTOS.filter((e) => e.inscrito).sort((a, b) => a.fecha.localeCompare(b.fecha));
  }

  cambiarTema(evento: ToggleCustomEvent) {
    this.oscuro = evento.detail.checked;
    document.documentElement.classList.toggle('ion-palette-dark', this.oscuro);
  }
}
