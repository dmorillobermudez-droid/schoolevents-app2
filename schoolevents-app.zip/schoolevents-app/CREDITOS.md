# Créditos

## Fotografías de la galería

Las fotos de la galería proceden de [Unsplash](https://unsplash.com) y se usan bajo la
[licencia de Unsplash](https://unsplash.com/license) (uso libre, sin obligación de atribuir; se indica
igualmente el origen). Están enlazadas desde `src/app/datos/fotos.ts`.

| Foto en la app | Identificador de la imagen en Unsplash |
|---|---|
| Torneo deportivo (esquí) | `photo-1551698618-1dfe5d97d256` |
| Festival cultural | `photo-1523580494863-6f3031224c94` |
| Torneo deportivo (atletismo) | `photo-1461896836934-ffe607ba8211` |
| Taller de arte | `photo-1513364776144-60967b0f800f` |
| Feria de ciencias | `photo-1532094349884-543bc11b234d` |
| Excursión de fin de curso | `photo-1529156069898-49953e39b3ac` |

> Cada imagen se encuentra en `https://images.unsplash.com/<identificador>`.
> Pendiente: añadir aquí el nombre de cada fotógrafo (aparece en la página de la foto en Unsplash).

## Fuentes tipográficas

- [Inter](https://rsms.me/inter/) © The Inter Project Authors, licencia SIL Open Font License 1.1.
- [Poppins](https://github.com/itfoundry/poppins) © Indian Type Foundry, licencia SIL Open Font License 1.1.

Instaladas con [Fontsource](https://fontsource.org).

## Iconos

[Ionicons](https://ionic.io/ionicons), licencia MIT.

## Frameworks

Angular, Ionic y Capacitor, licencia MIT.
